# Sugar Pie Bakery — Website Project (WEDE5020)

## Project Title
Sugar Pie Bakery Website — Part 2: Designing the Visuals (CSS Styling and Responsive Design)

## Student Information
- **Name:** Sufyaan Creighton
- **Student Number:** ST10539244
- **Subject:** WEDE5020

## Project Overview
This project is the design and development of a small business website for **Sugar Pie
Bakery**, a home-based bakery in Northeast Cobb, Georgia, owned and operated by Lola
Wilburn. The bakery currently has no dedicated website and relies on word-of-mouth
referrals and an Etsy storefront. The website gives the business an independent,
professional online presence where visitors can learn about the bakery, browse pie
offerings, and submit custom order enquiries.

The project is completed in three parts:
- **Part 1 — Building the Foundation:** planning, research, sitemap, file structure, and static HTML pages *(complete)*.
- **Part 2 — Designing the Visuals:** external CSS, desktop layout, and responsive design *(this submission)*.
- **Part 3 — Interactivity and Finalisation:** JavaScript functionality, testing, and final submission *(to follow)*.

## Website Goals and Objectives
- Establish a professional, independent online presence beyond Etsy and social media.
- Enable customers to browse pie offerings and place custom order enquiries directly.
- Increase local visibility and build trust through storytelling about the bakery and its owner.
- **KPIs:** enquiry form submissions per month; returning-customer orders; local search visibility.

## Key Features and Functionality
- **Home (index.html):** hero section, brief introduction, featured pies, call to action.
- **About Us (about.html):** the bakery's story, mission, vision, and owner profile.
- **Our Pies (products.html):** pies and baked goods with descriptions and pricing (in Rands).
- **Enquiry (enquiry.html):** custom-order enquiry form.
- **Contact (contact.html):** contact details, service areas, and a contact form.

## Timeline and Milestones
| Milestone | Target |
|---|---|
| Project planning, research, proposal approval | Week 1–2 |
| Sitemap, file structure, static HTML pages (Part 1) | Week 3–4 |
| CSS styling and responsive layout (Part 2) | Week 5–7 |
| JavaScript interactivity, testing, final submission (Part 3) | Week 8–10 |

## Sitemap
See `sitemap.png` in the repository root.

```
Home (index.html)
├── About Us (about.html)
├── Our Pies (products.html)
├── Enquiry (enquiry.html)
└── Contact (contact.html)
```

## File and Folder Structure
```
sugar-pie-bakery/
├── index.html
├── about.html
├── products.html
├── enquiry.html
├── contact.html
├── sitemap.png
├── README.md
├── css/
│   └── style.css        (Part 2 — linked from every page)
├── js/
│   └── script.js        (empty placeholder — Part 3)
└── images/
    ├── *.jpg            (site images, multiple resolutions for srcset)
    └── screenshots/     (responsive testing evidence)
```

## Part 1 Details
Part 1 delivered the proposal, sitemap, file/folder structure and five HTML-only pages
using semantic elements (`header`, `nav`, `main`, `section`, `article`, `footer`).

## Part 2 Details — CSS Styling and Responsive Design

### 1. External stylesheet
A single external stylesheet, `css/style.css`, is linked from the `<head>` of all five
pages. It is organised into numbered, commented sections (Reset, Base, Typography,
Layout, Components, Forms, Responsive) and uses one consistent naming convention
(lower-case, hyphenated class names such as `.card-grid` and `.hero-inner`).

### 2. Base style
- A CSS reset (`box-sizing: border-box`, zeroed margins/padding, `img { max-width: 100% }`) gives consistent rendering across browsers.
- Site-wide defaults are set once on `html`/`body` and inherited (font family, size, line height, colour), so few selectors are needed — this takes advantage of the cascade.
- Colours are stored as CSS custom properties (`--cream`, `--blush`, `--sage`, `--brown`, `--brown-light`) and reused throughout.

### 3. Typography
Georgia (serif) is used for headings and Segoe UI/Verdana/Arial (sans-serif) for body
text, with `font-size`, `font-weight` and `line-height` set per level. Heading sizes follow a
consistent scale (2.5rem / 1.75rem / 1.25rem) that steps down at the tablet and mobile breakpoints.

### 4. Layout (desktop)
- **CSS Grid** for the hero (2 columns), product cards (3 columns), About page (1fr / 2fr) and contact page (2 columns).
- **Flexbox** for the header/navigation bar and the map placeholders.
- A centred `.container` (90% width, max 68.75rem) keeps line lengths readable on wide screens.

### 5. Visual styles and interactivity
Colours, backgrounds, `border-radius` and `box-shadow` style the cards and buttons.
Pseudo-classes give feedback: `:hover` (nav links, cards lift, buttons, form fields),
`:focus` / `:focus-visible` (keyboard-visible outlines on links, buttons and inputs) and
`:active` (pressed state on nav links and buttons).

### 6. Responsive design
| Breakpoint | Media query | Changes |
|---|---|---|
| Desktop | default (above 64em / 1024px) | 3-column cards, 2-column hero/contact, horizontal nav |
| Tablet | `max-width: 64em` (1024px) | 2-column cards, smaller headings and section spacing, tighter nav |
| Mobile | `max-width: 40em` (640px) | single column everywhere, stacked full-width navigation with larger tap targets, smaller base font (93.75%), full-width buttons |

- **Relative units:** font sizes, spacing, radii and media queries use `rem`/`em`; widths use `%` and `fr`.
- **Responsive images:** product and hero images use `srcset` with width descriptors and `sizes` so the browser downloads an appropriately sized file. The hero uses a `<picture>` element to serve a square crop on small screens and a wide crop otherwise. All images have `alt` text and `width`/`height` attributes to prevent layout shift.
- **Image sources:** the illustrations in `images/` were generated for this project (drawn with Python's Pillow library) and are placeholders for real product photography.

### 7. Testing and iteration
The site was tested in Chromium using device emulation and checked for horizontal
scrolling at every size (none found). Iteration: the hero image was given rounded corners
after testing showed its background strip looked detached from the section on desktop.

| Device | Viewport | Screenshot |
|---|---|---|
| Desktop | 1440px | ![Desktop home](images/screenshots/index-desktop-1440.png) |
| Laptop | 1280px | ![Laptop home](images/screenshots/index-laptop-1280.png) |
| Tablet (iPad) | 810px | ![Tablet home](images/screenshots/index-tablet-ipad-810.png) |
| Mobile (iPhone 13) | 390px | ![iPhone home](images/screenshots/index-mobile-iphone13-390.png) |
| Mobile (Pixel 7) | 412px | ![Pixel home](images/screenshots/index-mobile-pixel7-412.png) |

Other pages at each size are in `images/screenshots/`:
`products-*`, `about-*`, `enquiry-*` and `contact-*` for desktop, tablet and iPhone.

## Changelog
| Date | Change |
|---|---|
| 2026-08-14 | Initial repository setup, Part 1 proposal, sitemap, file structure, and static HTML pages created. |
| 2026-08-14 | `css/style.css` and `js/script.js` kept as empty placeholders and unlinked, so the Part 1 submission is HTML only. |
| 2026-08-14 | Budget figures in the proposal converted to Rands; references switched to Harvard style. |
| 2026-09-28 | **Part 2:** wrote `css/style.css` (reset, base, typography, layout, components, forms) and linked it from all five pages. |
| 2026-09-28 | **Part 2:** replaced the image placeholder boxes with real `<img>` elements using `srcset`/`sizes`; added a `<picture>` element for the hero image; added images at multiple resolutions to `images/`. |
| 2026-09-28 | **Part 2:** restructured the homepage hero into a text block plus image (`.hero-inner`) to support the two-column desktop layout. |
| 2026-09-28 | **Part 2:** added tablet (`max-width: 64em`) and mobile (`max-width: 40em`) breakpoints; navigation stacks on mobile. |
| 2026-09-28 | **Part 2:** added responsive test screenshots to `images/screenshots/` and rounded the hero image corners after testing. |

## References
Harvard referencing style is used throughout.

- MDN Web Docs (n.d.) *Using media queries*. Available at: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_media_queries/Using_media_queries (Accessed: 28 September 2026).
- MDN Web Docs (n.d.) *CSS grid layout*. Available at: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_grid_layout (Accessed: 28 September 2026).
- MDN Web Docs (n.d.) *CSS flexible box layout*. Available at: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_flexible_box_layout (Accessed: 28 September 2026).
- MDN Web Docs (n.d.) *The picture element*. Available at: https://developer.mozilla.org/en-US/docs/Web/HTML/Element/picture (Accessed: 28 September 2026).
- MDN Web Docs (n.d.) *HTML: HyperText Markup Language*. Available at: https://developer.mozilla.org/en-US/docs/Web/HTML (Accessed: 14 August 2026).
- MDN Web Docs (n.d.) *CSS: Cascading Style Sheets*. Available at: https://developer.mozilla.org/en-US/docs/Web/CSS (Accessed: 14 August 2026).
- W3Schools (n.d.) *HTML tutorial*. Available at: https://www.w3schools.com/html/ (Accessed: 14 August 2026).
- Patch (2018) *Small business Q&A: Sugar Pie Bakery*. Available at: https://patch.com (Accessed: 14 August 2026).
