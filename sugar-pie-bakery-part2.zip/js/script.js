/* =========================================================
   Sugar Pie Bakery — JavaScript
   Intentionally left empty for Part 1 (Building the Foundation).
   This project's Part 1 submission is HTML only, as required.
   Interactivity will be added in Part 3.
   ========================================================= */
