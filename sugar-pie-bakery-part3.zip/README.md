# Sugar Pie Bakery — Website Project (WEDE5020)

## Project Title
Sugar Pie Bakery Website — Part 3: Enhancing Functionality and SEO

## Student Information
- **Name:** Sufyaan Creighton
- **Student Number:** ST10539244
- **Subject:** WEDE5020

## Project Overview
This project is the design and development of a small business website for **Sugar Pie
Bakery**, a home-based bakery in Northeast Cobb, Georgia, owned and operated by Lola
Wilburn. The bakery currently has no dedicated website and relies on word-of-mouth
referrals and an Etsy storefront. The website gives the business an independent,
professional online presence where visitors can learn about the bakery, browse pie
offerings, get an instant price estimate, and get in touch.

The project was completed in three parts:
- **Part 1 — Building the Foundation:** planning, research, sitemap, file structure, and static HTML pages. ✅
- **Part 2 — Designing the Visuals:** external CSS, desktop layout, and responsive design. ✅
- **Part 3 — Enhancing Functionality and SEO:** JavaScript interactivity, dynamic content, form validation, SEO and deployment. ✅ *(this submission)*

## Website Goals and Objectives
- Establish a professional, independent online presence beyond Etsy and social media.
- Enable customers to browse pie offerings and get an instant estimate before enquiring.
- Increase local visibility and build trust through storytelling about the bakery and its owner.
- **KPIs:** enquiry form submissions per month; returning-customer orders; local/organic search visibility.

## Key Features and Functionality
- **Home (index.html):** hero section, intro, featured pies, FAQ accordion, call to action.
- **About Us (about.html):** the bakery's story, mission, vision, and owner profile.
- **Our Pies (products.html):** pies rendered dynamically from a JS data array, with live search, sort/filter, and a click-to-enlarge image lightbox.
- **Enquiry (enquiry.html):** validated enquiry form that returns an instant estimated price and availability message.
- **Contact (contact.html):** validated contact form that compiles the message into an email for the visitor to send.

## Timeline and Milestones
| Milestone | Target | Status |
|---|---|---|
| Project planning, research, proposal approval | Week 1–2 | ✅ |
| Sitemap, file structure, static HTML pages (Part 1) | Week 3–4 | ✅ |
| CSS styling and responsive layout (Part 2) | Week 5–7 | ✅ |
| JavaScript interactivity, SEO, deployment (Part 3) | Week 8–10 | ✅ |

## Sitemap
See `sitemap.png` in the repository root for the visual site structure (not to be confused
with `sitemap.xml`, the SEO sitemap described in Part 3 below).

```
Home (index.html)
├── About Us (about.html)
├── Our Pies (products.html)
├── Enquiry (enquiry.html)
└── Contact (contact.html)
```

## File and Folder Structure
```
sugar-pie-bakery/
├── index.html
├── about.html
├── products.html
├── enquiry.html
├── contact.html
├── robots.txt            (Part 3 — SEO)
├── sitemap.xml            (Part 3 — SEO)
├── sitemap.png
├── README.md
├── css/
│   └── style.css          (Parts 2 & 3)
├── js/
│   └── script.js          (Part 3 — all interactivity)
└── images/
    ├── *.jpg              (site images, multiple resolutions for srcset)
    └── screenshots-p3/    (Part 3 testing evidence)
```

## Part 1 Details
Delivered the proposal, sitemap, file/folder structure and five HTML-only pages using
semantic elements (`header`, `nav`, `main`, `section`, `article`, `footer`).

## Part 2 Details
Delivered `css/style.css`: a CSS reset, base styles, a typographic scale, CSS Grid and
Flexbox layout, hover/focus/active states, and tablet (1024px) and mobile (640px)
breakpoints, plus `srcset`/`sizes` responsive images and a `<picture>` element on the hero.

## Part 3 Details — Enhancing Functionality and SEO

### Addressing Feedback from Part 2
Part 2 scored very well; the one note from the lecturer was that the changelog listed
several Part 1-era changes without clearly saying which (if any) came from formal
lecturer feedback. For clarity: **no formal Part 1 feedback had been released** at the
point Part 2 began — the currency (USD → Rand) and referencing-style (→ Harvard) changes
recorded in the Part 1→2 changelog were made at the student's own request, not in
response to a grader. This is now stated explicitly below rather than left ambiguous.
No Part 1 feedback has been received to date, so there are no Part-1-feedback-driven
corrections to apply in this submission; if feedback arrives after submission, it will
be logged in the changelog of the next revision.

### 1. JavaScript interactivity
A single shared file, `js/script.js`, is linked (with `defer`) from every page and is
organised into eight clearly commented sections. It only runs code for elements that
exist on the current page, so one file works safely across all five pages.

| Feature | Where | What it does |
|---|---|---|
| Mobile navigation toggle | all pages | A hamburger button (animates into an "✕") shows/hides the nav list on small screens. Closes on link click, outside click, or `Escape`. Uses `aria-expanded` for accessibility. |
| FAQ accordion | index.html | Four question/answer panels expand and collapse on click; only one open at a time; `aria-expanded` and `max-height` transitions handled in JS. |
| Dynamic content | products.html | The five products are **not** hard-coded in the HTML — they live in a `PRODUCTS` JS array and are built into the page with `createElement`/`innerHTML` on load. |
| Search & sort/filter | products.html | A search box filters by name/description (debounced), and a select re-sorts by price or filters by category, both re-rendering the grid live. |
| Image lightbox | products.html | Clicking a pie photo opens an enlarged view in a modal overlay, with Prev/Next navigation, `Escape`-to-close, click-outside-to-close, and focus handling. |
| Scroll animations | all pages | Sections fade/slide into view the first time they scroll into the viewport, using `IntersectionObserver` (not a scroll listener, for performance); disabled automatically for users with `prefers-reduced-motion`. |

### 2. SEO — On-page
| Requirement | Implementation |
|---|---|
| Keyword research | Each page targets a distinct phrase: "homemade pies Northeast Cobb", "coconut sweet potato pecan pie", etc., worked naturally into headings and copy. |
| Title tags & meta descriptions | Unique, keyword-led `<title>` and `<meta name="description">` on all five pages, kept within ~60/~160 characters. |
| Header tags | One `<h1>` per page, with `<h2>`/`<h3>` used in order to structure sections (verified — no skipped levels). |
| Image optimisation | Descriptive file names (`coconut-400.jpg`, not `IMG001.jpg`) and descriptive `alt` text on every image. |
| URL structure | Clean, descriptive, lower-case filenames (`products.html`, `enquiry.html`) with no query strings or IDs. |
| Internal linking | Footer navigation added to every page; contextual links added in body copy (e.g. "browse our full range of pies" → `products.html`, "read more about the bakery" → `about.html`). |
| Mobile-friendliness | Carried over from Part 2's responsive breakpoints; re-verified in Part 3 testing below. |

### 3. SEO — Off-page & additional requests
- **Backlinks / social media / local SEO:** outside the scope of a static student
  project with no live business accounts, but `Bakery`/`LocalBusiness` **structured data**
  (JSON-LD, in `index.html`) was added so search engines can understand this as a real
  local business, and Open Graph/Twitter Card meta tags were added to every page so
  links shared on social media show a proper preview card.
- **robots.txt** (repository root): allows all crawlers and points to `sitemap.xml`.
- **sitemap.xml** (repository root): lists all five pages with `lastmod`, `changefreq` and
  `priority`. **Note:** both files currently reference a placeholder domain
  (`sugarpiebakery.example.com`) since the site has no real domain yet — once deployed
  (see Deployment, below), update the URLs in `robots.txt`, `sitemap.xml` and every
  page's `<link rel="canonical">` / Open Graph tags to the real deployed URL.
- **Page speed:** below-the-fold images use `loading="lazy"` and `decoding="async"`; the
  hero image (above the fold) uses `fetchpriority="high"` instead so it is not delayed;
  all images have explicit `width`/`height` to prevent layout shift; `script.js` is
  loaded with `defer` so it never blocks page rendering; no external fonts or heavy
  libraries are loaded, keeping the page lightweight.
- **Security:** both forms include a hidden **honeypot field** (invisible to real
  visitors via CSS, but typically filled in by simple bots) that silently drops the
  submission if completed; all inputs have `maxlength` limits; HTML5 input types
  (`email`, `tel`, `date`) and `pattern`/validation constraints reduce malformed input;
  no inline event handlers are used anywhere (all JavaScript lives in the external,
  reviewable `script.js` file). Because this is a static site with no backend, true
  server-side protections (HTTPS, rate limiting, server-side validation, a CSP header)
  are the responsibility of whichever host it's deployed to — GitHub Pages and Netlify
  both serve over HTTPS by default.

### 4. HTML forms with JavaScript validation
Both `enquiry.html` and `contact.html` use the same validation pattern, implemented in
`script.js` (not just HTML5 `required` attributes), with per-field error messages and an
error-count banner:

- **enquiry.html** — asks what the visitor wants to order. Once the form passes
  validation, JavaScript looks up the selected product and **computes and displays an
  estimated price and an availability message** (which changes if the date needed is
  very soon) directly on the page, with no reload — this is the "response related to
  cost/availability" the brief asks for.
- **contact.html** — a general-purpose message form (name, email, message type, message).
  Once validated, the details are compiled into an email subject/body and the visitor's
  own email client is opened via a `mailto:` link addressed to the recipient set in the
  code (`hello@sugarpiebakery.com`), so the visitor can review and send it themselves.
- **AJAX form submission:** both forms also send a real, asynchronous `fetch()` POST
  request before showing their result (see `sendAjax()` in `script.js`), satisfying the
  brief's AJAX requirement. Since this is a static site with no backend of its own, the
  request target is `https://jsonplaceholder.typicode.com/posts`, a public fake-API
  testing service that accepts and echoes back POST requests — a placeholder for a real
  backend or email service (e.g. Formspree, Netlify Forms) that a production version of
  this site would point to instead.

### 5. Testing and iteration
Tested in Chromium (desktop, tablet and mobile viewports) with no console errors and no
horizontal overflow on any page. Evidence is in `images/screenshots-p3/`:

| What was tested | Screenshot(s) |
|---|---|
| Mobile hamburger menu (closed → open) | `01-mobile-nav-closed.png`, `02-mobile-nav-open.png` |
| FAQ accordion (closed → open) | `03-faq-closed.png`, `04-faq-open.png` |
| Dynamic product grid, search, "no results" state, sorting | `05-products-all.png`, `06-products-search.png`, `07-products-noresults.png`, `08-products-sorted.png` |
| Image lightbox (open, next image) | `09-lightbox-open.png`, `10-lightbox-next.png` |
| Enquiry form validation errors | `11-enquiry-errors.png` |
| Enquiry form dynamic quote result | `12-enquiry-quote.png` |
| Contact form validation errors | `13-contact-errors.png` |
| Full-page layouts at desktop/tablet/mobile, all 5 pages | `full-*.png` |

**Iteration:** testing surfaced a real bug — the footer's new quick-link navigation was
rendering in the same dark brown as the footer background, making the links invisible.
This was fixed by giving `.site-footer a` an explicit cream colour (see
`footer-contrast-fix.png` for the before/after, and the Changelog below).

## Deployment
**Live site:** https://sufyaan2004.github.io/Web-Development/ *(GitHub Pages)*

The site is a static site published with **GitHub Pages**, direct from this repository
(no build step needed — it's plain HTML/CSS/JS).

**To deploy or re-deploy after an update:**
1. Push the latest commit to the `main` branch.
2. In the GitHub repository, go to **Settings → Pages**.
3. Under "Build and deployment", set **Source** to "Deploy from a branch", **Branch** to
   `main` and folder to `/ (root)`, then click **Save**.
4. GitHub publishes the site at `https://<username>.github.io/<repository-name>/`
   within a minute or two. Re-deploys happen automatically on every push to `main`.
5. Once the real URL is known, update the placeholder `https://sugarpiebakery.example.com/`
   references in `robots.txt`, `sitemap.xml`, and each page's canonical/Open Graph tags.

## Changelog
| Date | Change |
|---|---|
| 2026-08-14 | Initial repository setup, Part 1 proposal, sitemap, file structure, and static HTML pages created. |
| 2026-08-14 | `css/style.css` and `js/script.js` kept as empty placeholders and unlinked, so the Part 1 submission is HTML only. |
| 2026-08-14 | **Own request, not lecturer feedback:** budget figures in the proposal converted to Rands; references switched to Harvard style. |
| 2026-09-28 | **Part 2:** wrote `css/style.css` (reset, base, typography, layout, components, forms) and linked it from all five pages. |
| 2026-09-28 | **Part 2:** replaced image placeholder boxes with real `<img>` elements using `srcset`/`sizes`; added a `<picture>` element for the hero; added images at multiple resolutions. |
| 2026-09-28 | **Part 2:** restructured the homepage hero into a text block plus image (`.hero-inner`) for the two-column desktop layout. |
| 2026-09-28 | **Part 2:** added tablet (`max-width: 64em`) and mobile (`max-width: 40em`) breakpoints; navigation stacked on mobile. |
| 2026-09-28 | **Part 2:** added responsive test screenshots; rounded the hero image corners after testing showed it looked detached from the section. |
| 2026-11-02 | **Part 2 feedback addressed:** clarified in this README that no formal Part 1 lecturer feedback existed at the time of the Part 1→2 changelog entries, so none of those entries were feedback-driven — see "Addressing Feedback from Part 2" above. |
| 2026-11-02 | **Part 3:** added `js/script.js` with mobile nav toggle, FAQ accordion, dynamic product rendering, search/sort, and an image lightbox. |
| 2026-11-02 | **Part 3:** rebuilt `products.html` to render its product grid from a JS data array instead of static HTML, and added a search/sort toolbar. |
| 2026-11-02 | **Part 3:** added full client-side validation, per-field error messages, a dynamic instant-quote result, and a real AJAX `fetch()` call to the enquiry form. |
| 2026-11-02 | **Part 3:** added validation, a honeypot anti-spam field, and a `mailto:`-based compiled-email send to the contact form. |
| 2026-11-02 | **Part 3:** added SEO meta tags (titles, descriptions, canonical, Open Graph/Twitter), `Bakery` structured data, `robots.txt` and `sitemap.xml`. |
| 2026-11-02 | **Part 3:** added `loading="lazy"`/`decoding="async"` to below-the-fold images, `fetchpriority="high"` to the hero image, and `defer` to the script tag, for page-speed. |
| 2026-11-02 | **Part 3:** fixed a contrast bug found during testing — footer navigation links were the same colour as the footer background and invisible; added explicit footer link styling. |
| 2026-11-02 | **Part 3:** prepared the site for deployment on GitHub Pages (see Deployment, above). |

## References
Harvard referencing style is used throughout.

- MDN Web Docs (n.d.) *Using media queries*. Available at: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_media_queries/Using_media_queries (Accessed: 28 September 2026).
- MDN Web Docs (n.d.) *CSS grid layout*. Available at: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_grid_layout (Accessed: 28 September 2026).
- MDN Web Docs (n.d.) *CSS flexible box layout*. Available at: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_flexible_box_layout (Accessed: 28 September 2026).
- MDN Web Docs (n.d.) *The picture element*. Available at: https://developer.mozilla.org/en-US/docs/Web/HTML/Element/picture (Accessed: 28 September 2026).
- MDN Web Docs (n.d.) *IntersectionObserver*. Available at: https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API (Accessed: 2 November 2026).
- MDN Web Docs (n.d.) *Using the Fetch API*. Available at: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch (Accessed: 2 November 2026).
- MDN Web Docs (n.d.) *ARIA: aria-expanded attribute*. Available at: https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Attributes/aria-expanded (Accessed: 2 November 2026).
- Google Search Central (n.d.) *SEO starter guide*. Available at: https://developers.google.com/search/docs/fundamentals/seo-starter-guide (Accessed: 2 November 2026).
- Google for Developers (n.d.) *Build and submit a sitemap*. Available at: https://developers.google.com/search/docs/crawling-indexing/sitemaps/build-sitemap (Accessed: 2 November 2026).
- schema.org (n.d.) *Bakery*. Available at: https://schema.org/Bakery (Accessed: 2 November 2026).
- JSONPlaceholder (n.d.) *Free fake API for testing*. Available at: https://jsonplaceholder.typicode.com/ (Accessed: 2 November 2026).
- GitHub Docs (n.d.) *Configuring a publishing source for your GitHub Pages site*. Available at: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site (Accessed: 2 November 2026).
- MDN Web Docs (n.d.) *HTML: HyperText Markup Language*. Available at: https://developer.mozilla.org/en-US/docs/Web/HTML (Accessed: 14 August 2026).
- MDN Web Docs (n.d.) *CSS: Cascading Style Sheets*. Available at: https://developer.mozilla.org/en-US/docs/Web/CSS (Accessed: 14 August 2026).
- W3Schools (n.d.) *HTML tutorial*. Available at: https://www.w3schools.com/html/ (Accessed: 14 August 2026).
- Patch (2018) *Small business Q&A: Sugar Pie Bakery*. Available at: https://patch.com (Accessed: 14 August 2026).
