/* =========================================================
   Sugar Pie Bakery — script.js (Part 3)
   One shared file, linked from every page. Each section checks
   that its elements exist before running, so this file works
   safely across all five pages without throwing errors.

   Sections:
    1. Mobile navigation toggle (hamburger menu)
    2. FAQ accordion
    3. Product data + dynamic rendering + search/sort (products.html)
    4. Image lightbox (modal gallery)
    5. Scroll-triggered fade-in animation
    6. Shared form-validation helpers
    7. Enquiry form — validation + dynamic quote response + AJAX demo
    8. Contact form — validation + compiled email (mailto) + AJAX demo
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {

  /* ============================================================
     1. MOBILE NAVIGATION TOGGLE
     A hamburger button shows only on small screens (see CSS,
     section 13). Clicking it expands/collapses the nav list and
     keeps the button's aria-expanded state in sync for
     accessibility. The menu also closes itself when a link is
     clicked, when Escape is pressed, or when the user clicks
     outside of it.
     ============================================================ */
  const navToggle = document.getElementById("nav-toggle");
  const mainNav = document.getElementById("main-nav");

  if (navToggle && mainNav) {
    const closeMenu = () => {
      mainNav.classList.remove("is-open");
      navToggle.setAttribute("aria-expanded", "false");
    };
    const openMenu = () => {
      mainNav.classList.add("is-open");
      navToggle.setAttribute("aria-expanded", "true");
    };

    navToggle.addEventListener("click", function () {
      const isOpen = mainNav.classList.contains("is-open");
      isOpen ? closeMenu() : openMenu();
    });

    mainNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", closeMenu);
    });

    document.addEventListener("click", function (e) {
      const clickedInsideNav = mainNav.contains(e.target) || navToggle.contains(e.target);
      if (!clickedInsideNav && mainNav.classList.contains("is-open")) closeMenu();
    });

    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && mainNav.classList.contains("is-open")) {
        closeMenu();
        navToggle.focus();
      }
    });
  }

  /* ============================================================
     2. FAQ ACCORDION
     Each trigger button toggles its sibling panel open/closed.
     max-height is set from scrollHeight so the CSS transition
     has a real value to animate to (auto cannot be transitioned).
     Only one panel is open at a time for a tidier experience.
     ============================================================ */
  const accordionTriggers = document.querySelectorAll(".accordion-trigger");

  accordionTriggers.forEach((trigger) => {
    const panel = document.getElementById(trigger.getAttribute("aria-controls"));
    if (!panel) return;

    trigger.addEventListener("click", function () {
      const isOpen = trigger.getAttribute("aria-expanded") === "true";

      // Close any other open panel first
      accordionTriggers.forEach((other) => {
        if (other !== trigger) {
          other.setAttribute("aria-expanded", "false");
          const otherPanel = document.getElementById(other.getAttribute("aria-controls"));
          if (otherPanel) otherPanel.style.maxHeight = null;
        }
      });

      if (isOpen) {
        trigger.setAttribute("aria-expanded", "false");
        panel.style.maxHeight = null;
      } else {
        trigger.setAttribute("aria-expanded", "true");
        panel.style.maxHeight = panel.scrollHeight + "px";
      }
    });
  });

  /* ============================================================
     3. PRODUCT DATA + DYNAMIC RENDERING + SEARCH/SORT
     The product listing is NOT hard-coded in products.html.
     Instead it lives here as data and is built into the page
     with DOM manipulation — this satisfies the "dynamically
     load content" requirement. A search box filters by name/
     description and a select re-sorts or filters by category.
     ============================================================ */
  const PRODUCTS = [
    {
      id: "coconut", name: "Coconut Pie", category: "pie", price: 250,
      desc: "Rich, melt-in-your-mouth coconut filling in a flaky homemade crust.",
      img: "images/coconut", alt: "A homemade coconut pie on a plate"
    },
    {
      id: "sweet-potato", name: "Sweet Potato Pie", category: "pie", price: 250,
      desc: "A Southern classic, spiced and baked fresh to order.",
      img: "images/sweet-potato", alt: "A homemade sweet potato pie on a plate"
    },
    {
      id: "pecan", name: "Pecan Pie", category: "pie", price: 280,
      desc: "Buttery, nutty, and always a crowd favourite at holiday tables.",
      img: "images/pecan", alt: "A homemade pecan pie on a plate"
    },
    {
      id: "shoofly", name: "Shoo-Fly Cupcakes", category: "cupcake", price: 220, unit: "/ dozen",
      desc: "A molasses-spiced twist on a classic, baked in individual cupcake form.",
      img: "images/shoofly", alt: "Three shoo-fly cupcakes"
    },
    {
      id: "custom", name: "Custom Orders", category: "custom", price: null,
      desc: "Have something specific in mind? We take custom orders for events and holidays.",
      img: "images/custom", alt: "A custom lattice-top pie"
    }
  ];

  const productGrid = document.getElementById("product-grid");

  if (productGrid) {
    const searchInput = document.getElementById("product-search");
    const sortSelect = document.getElementById("product-sort");
    const noResultsMsg = document.getElementById("no-results");

    function priceLabel(p) {
      if (p.price === null) return '<a href="enquiry.html">Enquire for pricing</a>';
      return "From R" + p.price + (p.unit ? " " + p.unit : "");
    }

    function renderProducts(list) {
      productGrid.innerHTML = "";

      if (list.length === 0) {
        if (noResultsMsg) noResultsMsg.hidden = false;
        return;
      }
      if (noResultsMsg) noResultsMsg.hidden = true;

      list.forEach((p) => {
        const article = document.createElement("article");
        article.className = "card fade-in is-visible";

        article.innerHTML = `
          <button type="button" class="card-img-button" data-lightbox-id="${p.id}">
            <img class="card-img" src="${p.img}-400.jpg"
                 srcset="${p.img}-400.jpg 400w, ${p.img}-800.jpg 800w"
                 sizes="(max-width: 40em) 90vw, (max-width: 64em) 45vw, 22rem"
                 alt="${p.alt}" width="400" height="300" loading="lazy" decoding="async">
          </button>
          <h3>${p.name}</h3>
          <p>${p.desc}</p>
          <p class="price">${priceLabel(p)}</p>
        `;
        productGrid.appendChild(article);
      });
    }

    function applyFiltersAndSort() {
      const term = (searchInput?.value || "").trim().toLowerCase();
      const sortValue = sortSelect?.value || "default";

      let list = PRODUCTS.filter((p) =>
        p.name.toLowerCase().includes(term) || p.desc.toLowerCase().includes(term)
      );

      if (sortValue === "price-asc") {
        list = list.slice().sort((a, b) => (a.price ?? Infinity) - (b.price ?? Infinity));
      } else if (sortValue === "price-desc") {
        list = list.slice().sort((a, b) => (b.price ?? -Infinity) - (a.price ?? -Infinity));
      } else if (sortValue === "pie" || sortValue === "cupcake" || sortValue === "custom") {
        list = list.filter((p) => p.category === sortValue);
      }

      renderProducts(list);
    }

    // Initial render
    renderProducts(PRODUCTS);

    // Debounced search so filtering doesn't run on every single keystroke
    let searchTimer;
    searchInput?.addEventListener("input", function () {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(applyFiltersAndSort, 150);
    });
    sortSelect?.addEventListener("change", applyFiltersAndSort);
  }

  /* ============================================================
     4. IMAGE LIGHTBOX (MODAL GALLERY)
     Clicking any product image opens an enlarged version in an
     overlay. Works with images added dynamically above because
     the click listener is delegated to the document rather than
     attached to each image individually.
     ============================================================ */
  const lightbox = document.getElementById("lightbox");

  if (lightbox) {
    const lightboxImg = document.getElementById("lightbox-img");
    const lightboxCaption = document.getElementById("lightbox-caption");
    const closeBtn = lightbox.querySelector(".lightbox-close");
    const prevBtn = lightbox.querySelector(".lightbox-prev");
    const nextBtn = lightbox.querySelector(".lightbox-next");

    let currentIndex = 0;
    let lastFocusedEl = null;

    function openLightbox(index) {
      const p = PRODUCTS[index];
      if (!p) return;
      currentIndex = index;
      lightboxImg.src = p.img + "-800.jpg";
      lightboxImg.alt = p.alt;
      lightboxCaption.textContent = p.name;
      lastFocusedEl = document.activeElement;
      lightbox.hidden = false;
      document.body.style.overflow = "hidden";
      closeBtn.focus();
    }

    function closeLightbox() {
      lightbox.hidden = true;
      document.body.style.overflow = "";
      if (lastFocusedEl) lastFocusedEl.focus();
    }

    function showRelative(step) {
      currentIndex = (currentIndex + step + PRODUCTS.length) % PRODUCTS.length;
      openLightbox(currentIndex);
    }

    document.addEventListener("click", function (e) {
      const trigger = e.target.closest("[data-lightbox-id]");
      if (!trigger) return;
      const index = PRODUCTS.findIndex((p) => p.id === trigger.dataset.lightboxId);
      if (index > -1) openLightbox(index);
    });

    closeBtn.addEventListener("click", closeLightbox);
    prevBtn.addEventListener("click", () => showRelative(-1));
    nextBtn.addEventListener("click", () => showRelative(1));

    lightbox.addEventListener("click", function (e) {
      if (e.target === lightbox) closeLightbox(); // click outside the image
    });

    document.addEventListener("keydown", function (e) {
      if (lightbox.hidden) return;
      if (e.key === "Escape") closeLightbox();
      if (e.key === "ArrowLeft") showRelative(-1);
      if (e.key === "ArrowRight") showRelative(1);
    });
  }

  /* ============================================================
     5. SCROLL-TRIGGERED FADE-IN ANIMATION
     Elements with the .fade-in class animate into view the first
     time they scroll into the viewport, using IntersectionObserver
     rather than a scroll event listener (better for performance).
     ============================================================ */
  const fadeEls = document.querySelectorAll(".fade-in:not(.is-visible)");

  if (fadeEls.length && "IntersectionObserver" in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });

    fadeEls.forEach((el) => observer.observe(el));
  } else {
    fadeEls.forEach((el) => el.classList.add("is-visible"));
  }

  /* ============================================================
     6. SHARED FORM-VALIDATION HELPERS
     Small utilities reused by both the enquiry and contact forms
     below, so validation logic and error-message display stay
     consistent across the site.
     ============================================================ */
  const PHONE_PATTERN = /^[0-9+()\s-]{7,20}$/;
  const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  function setFieldError(fieldEl, message) {
    const wrapper = fieldEl.closest(".field") || fieldEl.parentElement;
    const errorEl = wrapper.querySelector(".field-error");
    wrapper.classList.add("has-error");
    if (errorEl) errorEl.textContent = message;
    fieldEl.setAttribute("aria-invalid", "true");
  }

  function clearFieldError(fieldEl) {
    const wrapper = fieldEl.closest(".field") || fieldEl.parentElement;
    wrapper.classList.remove("has-error");
    fieldEl.removeAttribute("aria-invalid");
  }

  function showBanner(bannerEl, message, type) {
    if (!bannerEl) return;
    bannerEl.textContent = message;
    bannerEl.classList.remove("is-error", "is-success");
    bannerEl.classList.add("is-visible", type === "success" ? "is-success" : "is-error");
  }

  /* A simple honeypot check: a hidden field real visitors never
     fill in. If it has a value, the submission is almost
     certainly an automated bot, so we quietly drop it. */
  function isBot(form) {
    const hp = form.querySelector(".hp-field input");
    return !!(hp && hp.value.trim() !== "");
  }

  /* Demonstrates AJAX form submission per the brief: a real
     asynchronous POST request is sent using fetch(), without a
     full page reload. jsonplaceholder.typicode.com is a public
     fake-API testing service that accepts and echoes back POST
     requests — it stands in for a real backend/email service
     (e.g. Formspree) that would be wired up for production. */
  async function sendAjax(payload) {
    try {
      const response = await fetch("https://jsonplaceholder.typicode.com/posts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      return response.ok;
    } catch (err) {
      // Network issue or offline — the user-facing flow still
      // continues below, since the real "send" action for this
      // project is the mailto link / displayed quote, not this
      // demo endpoint.
      console.warn("AJAX demo request failed:", err);
      return false;
    }
  }

  /* ============================================================
     7. ENQUIRY FORM — validation + dynamic quote response
     enquiry.html: lets a customer ask about a specific pie.
     Once validated, JavaScript computes and displays an
     estimated price and availability message without reloading
     the page.
     ============================================================ */
  const enquiryForm = document.getElementById("enquiry-form");

  if (enquiryForm) {
    const banner = document.getElementById("enquiry-banner");
    const quoteResult = document.getElementById("quote-result");

    enquiryForm.addEventListener("submit", async function (e) {
      e.preventDefault();

      if (isBot(enquiryForm)) return; // silently ignore likely bot submissions

      let firstInvalid = null;
      const errors = [];

      const name = document.getElementById("name");
      const email = document.getElementById("email");
      const phone = document.getElementById("phone");
      const pieType = document.getElementById("pie-type");
      const dateNeeded = document.getElementById("date-needed");
      const message = document.getElementById("message");

      [name, email, phone, pieType, dateNeeded, message].forEach(clearFieldError);

      if (!name.value.trim()) {
        setFieldError(name, "Please enter your full name.");
        errors.push(name); firstInvalid = firstInvalid || name;
      }
      if (!EMAIL_PATTERN.test(email.value.trim())) {
        setFieldError(email, "Please enter a valid email address.");
        errors.push(email); firstInvalid = firstInvalid || email;
      }
      if (phone.value.trim() && !PHONE_PATTERN.test(phone.value.trim())) {
        setFieldError(phone, "Please enter a valid phone number (digits, spaces, + or - only).");
        errors.push(phone); firstInvalid = firstInvalid || phone;
      }
      if (!pieType.value) {
        setFieldError(pieType, "Please choose a pie or product.");
        errors.push(pieType); firstInvalid = firstInvalid || pieType;
      }
      if (dateNeeded.value) {
        const today = new Date(); today.setHours(0, 0, 0, 0);
        const chosen = new Date(dateNeeded.value);
        if (chosen < today) {
          setFieldError(dateNeeded, "Please choose today or a future date.");
          errors.push(dateNeeded); firstInvalid = firstInvalid || dateNeeded;
        }
      }
      if (message.value.trim().length < 10) {
        setFieldError(message, "Please add a little more detail (at least 10 characters).");
        errors.push(message); firstInvalid = firstInvalid || message;
      }

      if (errors.length) {
        showBanner(banner, `Please fix ${errors.length} field${errors.length > 1 ? "s" : ""} below before submitting.`, "error");
        quoteResult?.classList.remove("is-visible");
        firstInvalid.focus();
        return;
      }

      banner.classList.remove("is-visible");

      const submitBtn = enquiryForm.querySelector('button[type="submit"]');
      const originalBtnText = submitBtn.textContent;
      submitBtn.disabled = true;
      submitBtn.textContent = "Sending...";

      await sendAjax({
        form: "enquiry",
        name: name.value.trim(),
        email: email.value.trim(),
        phone: phone.value.trim(),
        pieType: pieType.value,
        dateNeeded: dateNeeded.value,
        message: message.value.trim()
      });

      submitBtn.disabled = false;
      submitBtn.textContent = originalBtnText;

      // Build the dynamic quote: look up the pie, work out a
      // rough price, and give an availability message based on
      // how soon it's needed.
      const product = PRODUCTS.find((p) => p.id === pieType.value);
      const priceText = product && product.price !== null
        ? "R" + product.price + (product.unit ? " " + product.unit : "")
        : "Quoted individually — we'll confirm by email";

      let availabilityText = "We can usually have this ready within 2–3 days of your order date.";
      if (dateNeeded.value) {
        const today = new Date(); today.setHours(0, 0, 0, 0);
        const chosen = new Date(dateNeeded.value);
        const daysAway = Math.round((chosen - today) / 86400000);
        if (daysAway <= 1) {
          availabilityText = "That's a rush order — please call us on (770) 555-0142 to confirm we can make it in time.";
        } else if (daysAway <= 3) {
          availabilityText = "Short notice, but usually doable — we'll confirm availability by email within a few hours.";
        }
      }

      document.getElementById("quote-pie").textContent = product ? product.name : pieType.value;
      document.getElementById("quote-price").textContent = priceText;
      document.getElementById("quote-date").textContent = dateNeeded.value || "Not specified";
      document.getElementById("quote-availability").textContent = availabilityText;

      quoteResult.classList.add("is-visible");
      showBanner(banner, "Thanks! Here's your estimated quote — we'll follow up by email to confirm.", "success");
      quoteResult.scrollIntoView({ behavior: "smooth", block: "center" });

      enquiryForm.reset();
    });
  }

  /* ============================================================
     8. CONTACT FORM — validation + compiled email (mailto)
     contact.html: a general message to the bakery. Once
     validated, the details are compiled into an email and the
     visitor's own email client opens with it ready to send —
     per the brief, this is the final "recipient stated in the
     code" delivery mechanism for this static, backend-free site.
     ============================================================ */
  const contactForm = document.getElementById("contact-form");
  const RECIPIENT_EMAIL = "hello@sugarpiebakery.com";

  if (contactForm) {
    const banner = document.getElementById("contact-banner");

    contactForm.addEventListener("submit", async function (e) {
      e.preventDefault();

      if (isBot(contactForm)) return;

      const name = document.getElementById("c-name");
      const email = document.getElementById("c-email");
      const type = document.getElementById("c-type");
      const message = document.getElementById("c-message");

      [name, email, type, message].forEach(clearFieldError);

      let firstInvalid = null;
      const errors = [];

      if (!name.value.trim()) {
        setFieldError(name, "Please enter your full name.");
        errors.push(name); firstInvalid = firstInvalid || name;
      }
      if (!EMAIL_PATTERN.test(email.value.trim())) {
        setFieldError(email, "Please enter a valid email address.");
        errors.push(email); firstInvalid = firstInvalid || email;
      }
      if (!type.value) {
        setFieldError(type, "Please choose a message type.");
        errors.push(type); firstInvalid = firstInvalid || type;
      }
      if (message.value.trim().length < 10) {
        setFieldError(message, "Please add a little more detail (at least 10 characters).");
        errors.push(message); firstInvalid = firstInvalid || message;
      }

      if (errors.length) {
        showBanner(banner, `Please fix ${errors.length} field${errors.length > 1 ? "s" : ""} below before submitting.`, "error");
        firstInvalid.focus();
        return;
      }

      banner.classList.remove("is-visible");

      const submitBtn = contactForm.querySelector('button[type="submit"]');
      const originalBtnText = submitBtn.textContent;
      submitBtn.disabled = true;
      submitBtn.textContent = "Sending...";

      await sendAjax({
        form: "contact",
        name: name.value.trim(),
        email: email.value.trim(),
        type: type.value,
        message: message.value.trim()
      });

      submitBtn.disabled = false;
      submitBtn.textContent = originalBtnText;

      // Compile everything into an email and hand it to the
      // visitor's own email client via a mailto: link.
      const subject = `[Website — ${type.options[type.selectedIndex].text}] Message from ${name.value.trim()}`;
      const body =
        `Name: ${name.value.trim()}\n` +
        `Email: ${email.value.trim()}\n` +
        `Type: ${type.options[type.selectedIndex].text}\n\n` +
        `${message.value.trim()}`;

      const mailtoLink = `mailto:${RECIPIENT_EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

      showBanner(banner, "Thanks! Opening your email app so you can send this message to us.", "success");
      window.location.href = mailtoLink;

      contactForm.reset();
    });
  }

});
